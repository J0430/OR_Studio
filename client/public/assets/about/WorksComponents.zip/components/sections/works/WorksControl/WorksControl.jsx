import dynamic from "next/dynamic";
import styles from "./WorksControl.module.scss";

const CategoryTabs = dynamic(() => import("@components/common/CategoryTab/CategoryTabs"));
const DropdownMenu = dynamic(() => import("@components/common/DropdownMenu/DropdownMenu"));

const WorksControl = ({ categories, selectedCategory, onCategorySelect }) => {
  const filteredCategories = categories.filter((category) => category !== "Works");

  return (
    <section className={styles.worksControl} aria-label="Project Categories">
      <div className={styles.tabsWrapper}>
        <div className={styles.worksTitleBox}>
          <h1 className={styles.worksTitle}>Works</h1>
        </div>
        <CategoryTabs
          categories={filteredCategories}
          selectedCategory={selectedCategory}
          onCategorySelect={onCategorySelect}
        />
      </div>
      <div className={styles.dropdownWrapper}>
        <DropdownMenu
          categories={categories}
          selectedCategory={selectedCategory}
          onCategorySelect={onCategorySelect}
        />
      </div>
    </section>
  );
};

export default WorksControl;