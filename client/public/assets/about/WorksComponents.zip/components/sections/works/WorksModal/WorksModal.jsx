import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import DirectionalButton from "@components/common/DirectionalButton/DirectionalButton";
import Image from "next/image";
import styles from "./WorksModal.module.scss";

function WorksModal({ selectedImage, work, onClose }) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [swipeDirection, setSwipeDirection] = useState(1);
  const modalContentRef = useRef(null);
  const touchStartX = useRef(0);

  useEffect(() => {
    if (work && selectedImage) {
      const index = work.images?.indexOf(selectedImage);
      if (index !== -1) setCurrentImageIndex(index);
    }
  }, [work, selectedImage]);

  const handleNext = useCallback(() => setCurrentImageIndex((prev) => (prev + 1) % work.images.length), [work.images]);
  const handlePrevious = useCallback(() => setCurrentImageIndex((prev) => (prev - 1 + work.images.length) % work.images.length), [work.images]);

  return (
    <motion.div className={styles.modalContainer} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <div className={styles.modalBackdrop} onClick={onClose} />
      <motion.div className={styles.modalContent} ref={modalContentRef} initial={{ scale: 0.8 }} animate={{ scale: 1 }} exit={{ scale: 0.8 }}>
        <button className={styles.closeButton} onClick={onClose}>✕</button>
        <motion.div className={styles.imageWrapper} layoutId={selectedImage}>
          <DirectionalButton direction="left" onClick={handlePrevious} />
          <Image src={work.images[currentImageIndex]} alt="Work" width={900} height={700} quality={80} />
          <DirectionalButton direction="right" onClick={handleNext} />
        </motion.div>
        <div className={styles.thumbnailGallery}>
          {work.images.map((image, idx) => (
            <div key={idx} onClick={() => setCurrentImageIndex(idx)} className={idx === currentImageIndex ? styles.activeThumbnail : ""}>
              <Image src={image} alt="Thumbnail" width={100} height={75} />
            </div>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
}

export default WorksModal;